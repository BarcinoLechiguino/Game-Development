function [q] = matrix2quaternion(R)
%
% Rotation Matrix to Quaternion. The Quaternion is returned with dimensions [4, 1].
%
% INPUTS:
% R -> Rotation Matrix
%
% OUTPUTS:
% q -> Quaternion.

q( 1, 1 ) = sqrt(1 + R( 1, 1 ) + R( 2, 2 ) + R( 3, 3 )) / 2;
q( 2, 1 ) = (R( 3, 2 ) - R( 2, 3 )) / (4 * q( 1, 1 ));
q( 3, 1 ) = (R( 1, 3 ) - R( 3, 1 )) / (4 * q( 1, 1 ));
q( 4, 1 ) = (R( 2, 1 ) - R( 1, 2 )) / (4 * q( 1, 1 ));