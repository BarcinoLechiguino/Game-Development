function [R] = rotationvector2matrix(r)
%
%
% Rotation vector to Rotation Matrix. The vec has to have the following dimensions [3, 1]
%
% INPUTS:
% r -> Rotation Vector encoded in the Rotation Matrix.
%
% OUTPUTS:
% R -> Rotation Matrix.
%

ur = norm(r);
r = r / ur;

rx = [0 -r(3) r(2);
      r(3) 0 -r(1);
     -r(2) r(1) 0];
 
 R = eye(3) * cosd(ur) + (1 - cosd(ur)) * (r * r') + rx * sind(ur);