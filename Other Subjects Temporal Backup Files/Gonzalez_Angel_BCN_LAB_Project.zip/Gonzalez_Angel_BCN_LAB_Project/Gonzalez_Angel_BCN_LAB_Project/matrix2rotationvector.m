function [r] = matrix2rotationvector(R)
%
%
% Rotation Matrix to rotation vector. Rotation Vector is returned in dimensions [3, 1].
%
% INPUTS:
% R -> Rotation Matrix.
%
% OUTPUTS:
% r -> Rotation Vector encoded in the Rotation Matrix.
%

r(2) = asind(R( 3, 1 ));
r(1) = atan2d((R( 3, 2 ) / cosd(r(2))), (R( 3, 3 ) / cosd(r(2))));
r(3) = atan2d((R( 2, 1 ) / cosd(r(2))), (R( 1, 1 ) / cosd(r(2))));