function varargout = trackBall(varargin)
% TRACKBALL MATLAB code for trackBall.fig
%      TRACKBALL, by itself, creates a new TRACKBALL or raises the existing
%      singleton*.
%
%      H = TRACKBALL returns the handle to a new TRACKBALL or the handle to
%      the existing singleton*.
%
%      TRACKBALL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRACKBALL.M with the given input arguments.
%
%      TRACKBALL('Property','Value',...) creates a new TRACKBALL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before trackBall_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to trackBall_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help trackBall

% Last Modified by GUIDE v2.5 24-Nov-2016 11:52:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @trackBall_OpeningFcn, ...
                   'gui_OutputFcn',  @trackBall_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before trackBall is made visible.
function trackBall_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to trackBall (see VARARGIN)


set(hObject,'WindowButtonDownFcn',{@my_MouseClickFcn,handles.axes1});
set(hObject,'WindowButtonUpFcn',{@my_MouseReleaseFcn,handles.axes1});
axes(handles.axes1);

handles.Cube=DrawCube(eye(3));

set(handles.axes1,'CameraPosition',...
    [0 0 5],'CameraTarget',...
    [0 0 -5],'CameraUpVector',...
    [0 1 0],'DataAspectRatio',...
    [1 1 1]);

set(handles.axes1,'xlim',[-3 3],'ylim',[-3 3],'visible','off','color','none');

% Choose default command line output for trackBall
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes trackBall wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = trackBall_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function my_MouseClickFcn(obj,event,hObject)

handles=guidata(obj);
xlim = get(handles.axes1,'xlim');
ylim = get(handles.axes1,'ylim');
mousepos=get(handles.axes1,'CurrentPoint');
xmouse = mousepos(1,1);
ymouse = mousepos(1,2);

if xmouse > xlim(1) && xmouse < xlim(2) && ymouse > ylim(1) && ymouse < ylim(2)

    set(handles.figure1,'WindowButtonMotionFcn',{@my_MouseMoveFcn,hObject});
    
    %The position (x-y) of the mouse is stored on-click. It is then stored in the handles. 
    handles.x_click = xmouse;
    handles.y_click = ymouse;
end
guidata(hObject,handles)

function my_MouseReleaseFcn(obj,event,hObject)
handles=guidata(hObject);
set(handles.figure1,'WindowButtonMotionFcn','');
guidata(hObject,handles);

function my_MouseMoveFcn(obj,event,hObject)

handles=guidata(obj);
xlim = get(handles.axes1,'xlim');
ylim = get(handles.axes1,'ylim');
mousepos=get(handles.axes1,'CurrentPoint');
xmouse = mousepos(1,1);
ymouse = mousepos(1,2);

% --- VARS
i_vect = zeros(3, 1);
f_vect = zeros(3, 1);
r = 1;

if xmouse > xlim(1) && xmouse < xlim(2) && ymouse > ylim(1) && ymouse < ylim(2)
    
    % In order to rotate the figure, the Holroyd's arcball method is
    % required (as specified in the project's presentation document).
    
    % Get the mouse position ( X, Y ) that was previously stored.
    m_x = handles.x_click;
    m_y = handles.y_click;
    
    % --- FIRST STEP: Get Initial Vector From Initial Mouse Pos
    if ((m_x^2 + m_y^2) < (1 / 2 * r^2)) %CF 2nd (). Maybe change 1/2 to 0.5.
        m_z     = sqrt(r^2 - m_x^2 - m_y^2);                                    % Apply Holroyd
        i_vect  = [m_x; m_y; m_z];
    end
    
    if ((m_x^2 + m_y^2) >= (1 / 2 * r^2)) %CF Both ().
        i_vect  = [m_x; m_y; (r^2) / (2 * sqrt(m_x^2 + m_y^2))];             % Apply Holroyd
        i_vect  = (r * i_vect) / norm(i_vect);                               % Making sure that i_vect is nomalized.
    end
    
    % --- SECOND STEP: Get Final Vector From Current Mouse Pos
    if ((xmouse^2 + ymouse^2) < (1 / 2 * r^2))  %CF Both ().
        zmouse  = sqrt(r^2 - xmouse^2 - ymouse^2);                           % Apply Holroyd
        f_vect  = [xmouse; ymouse; zmouse];
    end
    
    if ((xmouse^2 + ymouse^2) >= (1 / 2 * r^2))
        f_vect  = [xmouse; ymouse; (r^2) / (2 * sqrt(xmouse^2 + ymouse^2))]; % Apply Holroyd
        f_vect  = (r * f_vect) / norm(f_vect);                               % Making sure that f_vect is normalized.
    end
    
    % --- THIRD STEP: Rotating The Figure %CF r_axis & r_angle to u & phi
    u           = cross(f_vect, i_vect);                                      % Getting rotation axis.
    phi         = -acosd(dot(f_vect, i_vect));                                % Getting the rotation angle between i_vect and f_vect. The angle MUST be negated.
    
    R = euleruphi2mat(u, phi);
    handles.Cube = RedrawCube(R, handles);
    
end
guidata(hObject,handles);

function h = DrawCube(R)

M0 = [ -1 -1  1;    %Node 1
       -1  1  1;    %Node 2
        1  1  1;    %Node 3
        1 -1  1;    %Node 4
       -1 -1 -1;    %Node 5
       -1  1 -1;    %Node 6
        1  1 -1;    %Node 7
        1 -1 -1];   %Node 8

M = (R*M0')';


x = M(:,1);
y = M(:,2);
z = M(:,3);


con = [1 2 3 4;
       5 6 7 8;
       4 3 7 8;
       1 2 6 5;
       1 4 8 5;
       2 3 7 6]';

x = reshape(x(con(:)),[4,6]);
y = reshape(y(con(:)),[4,6]);
z = reshape(z(con(:)),[4,6]);

c = 1/255*[255 248 88;
           0   0   0;
           57  183 225;
           57  183 0;
           255 178 0;
           255 0   0];

h = fill3(x,y,z, 1:6);

for q = 1:length(c)
    h(q).FaceColor = c(q,:);
end

% NOTE: This function has been modified to allow access to the handles
% when the figure is drawn. Due to the aforementioned modification,
% anything that is on the handles can be modified.
% Mainly used to update the GUIDE fields any time the figure is drawn.
function h = RedrawCube(R,hin)

h = hin.Cube;
c = 1/255*[255 248 88;
           0   0   0;
           57  183 225;
           57  183 0;
           255 178 0;
           255 0   0];

M0 = [ -1 -1  1;        %Node 1
       -1  1  1;        %Node 2
        1  1  1;        %Node 3
        1 -1  1;        %Node 4
       -1 -1 -1;        %Node 5
       -1  1 -1;        %Node 6
        1  1 -1;        %Node 7
        1 -1 -1];       %Node 8

M = (R*M0')';


x = M(:,1);
y = M(:,2);
z = M(:,3);


con = [1 2 3 4;
       5 6 7 8;
       4 3 7 8;
       1 2 6 5;
       1 4 8 5;
       2 3 7 6]';

x = reshape(x(con(:)),[4,6]);
y = reshape(y(con(:)),[4,6]);
z = reshape(z(con(:)),[4,6]);

for q = 1:6
    h(q).Vertices = [x(:,q) y(:,q) z(:,q)];
    h(q).FaceColor = c(q,:);
end

% --- Setting every parameter according to the current rotation matrix.
SetGuideRotMat(hin, R);
SetEulerUPhiFromRotMat(hin, R);
SetEulerAnglesFromRotMat(hin, R);
SetRotationVectorFromRotMat(hin, R);
SetQuaternionFromRotMat(hin, R);

% --- This Method executes when "Button_Quaternion" is pressed.
function Press_Button_Quaternion_Callback(hObject, eventdata, handles)      %CF Name & space after comments.
% hObject   --> Handle to Press_Button_Quaternion (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

quat_0 = str2double(get(handles.q_0_edit, 'String'));
quat_1 = str2double(get(handles.q_1_edit, 'String'));
quat_2 = str2double(get(handles.q_2_edit, 'String'));
quat_3 = str2double(get(handles.q_3_edit, 'String'));

q = [quat_0; quat_1; quat_2; quat_3];
R = quaternion2matrix(q);

handles.Cube = RedrawCube(R, handles);

% --- q_0
function q_0_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to q_0_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).   

% get(hObject,'String') returns the value of q_0_edit as text.
% str2double(get(hObject, 'String')) returns the value of q_0_edit as a double.

% quat_0 = str2double(get(hObject, 'String'));
% 
% q = [quat_0; quat_1; quat_2; quat_3];
% R = quaternion2matrix(q);
% 
% handles.Cube = RedrawCube(R, handles);

% - Executes during object creation after all properties have been set. 
function q_0_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to q_0_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white background on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- q_1
function q_1_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to q_1_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).   

% get(hObject,'String') returns the value of q_1_edit as text.
% str2double(get(hObject, 'String')) returns the value of q_1_edit as a double.

% quat_1 = str2double(get(hObject, 'String'));
% 
% q = [quat_0; quat_1; quat_2; quat_3];
% R = quaternion2matrix(q);
% 
% handles.Cube = RedrawCube(R, handles);

% - Executes during object creation after all properties have been set. 
function q_1_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to q_1_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white background on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- q_2
function q_2_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to q_2_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).   

% quat_2 = str2double(get(hObject, 'String'));
% 
% q = [quat_0; quat_1; quat_2; quat_3];
% R = quaternion2matrix(q);
% 
% handles.Cube = RedrawCube(R, handles);

% get(hObject,'String') returns the value of q_2_edit as text.
% str2double(get(hObject, 'String')) returns the value of q_2_edit as a double.

% - Executes during object creation after all properties have been set. 
function q_2_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to q_2_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white background on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- q_3
function q_3_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to q_3_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).   

% get(hObject,'String') returns the value of q_3_edit as text.
% str2double(get(hObject, 'String')) returns the value of q_3_edit as a double.

% quat_3 = str2double(get(hObject, 'String'));
% 
% q = [quat_0; quat_1; quat_2; quat_3];
% R = quaternion2matrix(q);
% 
% handles.Cube = RedrawCube(R, handles);

% - Executes during object creation after all properties have been set. 
function q_3_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to q_3_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white background on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- This Method executes when "Reset_Button" is pressed.
function Reset_Button_Callback(hObject, eventdata, handles)
% hObject   --> Handle to Reset_Button (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

R = eye(3);
handles.Cube = RedrawCube(R, handles);
SetGuideRotMat(handles, R);

% --- Phi
function u_angle_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to u_angle_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of u_angle_edit as text.
% str2double(get(hObject, 'String')) returns the value of u_angle_edit as a double.

% - Executes during object creation after all properties have been set. 
function u_angle_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to u_angle_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- U
% -- X
function u_x_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to u_x_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of u_x_edit as text.
% str2double(get(hObject, 'String')) returns the value of u_x_edit as a double.

% - Executes during object creation after all properties have been set. 
function u_x_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to u_x_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Y
function u_y_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to u_y_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of u_y_edit as text.
% str2double(get(hObject, 'String')) returns the value of u_y_edit as a double.

% - Executes during object creation after all properties have been set. 
function u_y_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to u_y_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Z
function u_z_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to u_z_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of u_z_edit as text.
% str2double(get(hObject, 'String')) returns the value of u_z_edit as a double.

% - Executes during object creation after all properties have been set. 
function u_z_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to u_z_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- This Method executes when "Button_Euler_Principal_Angle_And_Axis" is pressed.
function Press_Button_Euler_Principal_Angle_And_Axis_Callback(hObject, eventdata, handles) %CF Name was tweaked in several places.
% hObject   --> Handle to Press_Button_Euler_Principal_Angle_And_Axis (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

u_x = str2double(get(handles.u_x_edit, 'String'));
u_y = str2double(get(handles.u_y_edit, 'String'));
u_z = str2double(get(handles.u_z_edit, 'String'));

u   = [u_x; u_y; u_z];
phi = str2double(get(handles.u_angle_edit, 'String'));
R   = euleruphi2mat(u, phi);

handles.Cube = RedrawCube(R, handles);

% --- Euler Angles
% -- Phi
function phi_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to phi_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of phi_edit as text.
% str2double(get(hObject, 'String')) returns the value of phi_edit as a double.

% - Executes during object creation after all properties have been set. 
function phi_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to phi_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Theta
function theta_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to theta_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of theta_edit as text.
% str2double(get(hObject, 'String')) returns the value of theta_edit as a double.

% - Executes during object creation after all properties have been set. 
function theta_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to theta_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Psi
function psi_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to psi_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of psi_edit as text.
% str2double(get(hObject, 'String')) returns the value of psi_edit as a double.

% - Executes during object creation after all properties have been set. 
function psi_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to psi_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% --- This Method executes when "Button_Euler_Angles" is pressed.
function Press_Button_Euler_Angles_Callback(hObject, eventdata, handles)
% hObject   --> Handle to Press_Button_Euler_Angles (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

phi     = str2double(get(handles.phi_edit, 'String'));
theta   = str2double(get(handles.theta_edit, 'String'));
psi     = str2double(get(handles.psi_edit, 'String'));

R   = eulerangles2matrix(psi, theta, phi);

handles.Cube = RedrawCube(R, handles);


% --- This Method executes when "Push_Button_Rotation_Vector" is pressed.
x_rot_v = str2double(get(handles.x_rot_edit, 'String'));
y_rot_v = str2double(get(handles.y_rot_edit, 'String'));
z_rot_v = str2double(get(handles.z_rot_edit, 'String'));

r = [x_rot_v; y_rot_v; z_rot_v];
R = rotationvector2matrix(r);       %CF

handles.Cube = RedrawCube(R, handles);

% --- Rotation Vector
% -- X
function x_rot_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to x_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of x_rot_edit as text.
% str2double(get(hObject, 'String')) returns the value of x_rot_edit as a double.

% - Executes during object creation after all properties have been set. 
function x_rot_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to x_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Y
function y_rot_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to y_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of y_rot_edit as text.
% str2double(get(hObject, 'String')) returns the value of y_rot_edit as a double.

% - Executes during object creation after all properties have been set. 
function y_rot_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to y_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end


% -- Z
function z_rot_edit_Callback(hObject, eventdata, handles)
% hObject   --> Handle to z_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Structure with handles and user data (see GUIDATA).

% get(hObject, 'String') returns the value of z_rot_edit as text.
% str2double(get(hObject, 'String')) returns the value of z_rot_edit as a double.

% - Executes during object creation after all properties have been set. 
function z_rot_edit_CreateFcn(hObject, eventdata, handles)
% hObject   --> Handle to z_rot_edit (see GCBO).
% eventdata --> Reserved --- To Be Defined in a future version of MATLAB.
% handles   --> Empty --- Handles will not be created until all CreateFncs have been called.

% Edit Controls usually have a white backtround on Windows OS.
% See ISPC and COMPUTER.

if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end



% ------------------------------------------------------------------------
% -------------------------------- UTILS ---------------------------------
% ------------------------------------------------------------------------

function ResetQuaternion(handles)
    set(handles.q_0_edit, 'String', '0');
    set(handles.q_1_edit, 'String', '0');
    set(handles.q_2_edit, 'String', '0');
    set(handles.q_3_edit, 'String', '0');
    
function ResetEulerUPhi(handles)
    set(handles.u_angle_edit, 'String', '0');
    set(handles.u_x_edit, 'String', '0');
    set(handles.u_y_edit, 'String', '0');
    set(handles.u_z_edit, 'String', '0');
    
function  ResetEulerAngles(handles)
    set(handles.phi_edit,  'String', '0');
    set(handles.theta_edit, 'String', '0');
    set(handles.psi_edit,  'String', '0');
    
function ResetRotationVector(handles)
    set(handles.x_rot_edit, 'String', '0');
    set(handles.y_rot_edit, 'String', '0');
    set(handles.z_rot_edit, 'String', '0');
    
function ResetRotationMatrix(handles)
    set(handles.rm_11, 'String', '1');
    set(handles.rm_12, 'String', '0');
    set(handles.rm_13, 'String', '0');
    set(handles.rm_21, 'String', '0');
    set(handles.rm_22, 'String', '1');
    set(handles.rm_23, 'String', '0');
    set(handles.rm_31, 'String', '0');
    set(handles.rm_32, 'String', '0');
    set(handles.rm_33, 'String', '1');
    
function SetGuideRotMat(handles, R)
     set(handles.rm_11, 'String', R( 1, 1 ));
     set(handles.rm_12, 'String', R( 1, 2 ));
     set(handles.rm_13, 'String', R( 1, 3 ));
     set(handles.rm_21, 'String', R( 2, 1 ));
     set(handles.rm_22, 'String', R( 2, 2 ));
     set(handles.rm_23, 'String', R( 2, 3 ));
     set(handles.rm_31, 'String', R( 3, 1 ));
     set(handles.rm_32, 'String', R( 3, 2 ));
     set(handles.rm_33, 'String', R( 3, 3 ));
    
function R = GetGuideRotMat(handles) %CF rotation_matrix to R
    R( 1, 1 ) = str2double(get(handles.rm_11, 'String'));
    R( 1, 2 ) = str2double(get(handles.rm_12, 'String'));
    R( 1, 3 ) = str2double(get(handles.rm_13, 'String'));
    R( 2, 1 ) = str2double(get(handles.rm_21, 'String'));
    R( 2, 2 ) = str2double(get(handles.rm_22, 'String'));
    R( 2, 3 ) = str2double(get(handles.rm_23, 'String'));
    R( 3, 1 ) = str2double(get(handles.rm_31, 'String'));
    R( 3, 2 ) = str2double(get(handles.rm_32, 'String'));
    R( 3, 3 ) = str2double(get(handles.rm_33, 'String'));
    
% --- OTHERS
function SetEulerUPhiFromRotMat(handles, R)
    [u, phi] = matrix2euleruphi(R);
    set(handles.u_angle_edit, 'String', phi);
    set(handles.u_x_edit, 'String', u(1));
    set(handles.u_y_edit, 'String', u(2));
    set(handles.u_z_edit, 'String', u(3));
    
function SetEulerAnglesFromRotMat(handles, R)
    [a_1, a_2, a_3] = matrix2eulerangles(R);
    set(handles.phi_edit, 'String', a_1);
    set(handles.theta_edit, 'String', a_2);
    set(handles.psi_edit, 'String', a_3);
    
function SetRotationVectorFromRotMat(handles, R)
    rot_vec = matrix2rotationvector(R)
    set(handles.x_rot_edit, 'String', rot_vec(1));
    set(handles.y_rot_edit, 'String', rot_vec(2));
    set(handles.z_rot_edit, 'String', rot_vec(3));
    
function SetQuaternionFromRotMat(handles, R)
    quat = matrix2quaternion(R);
    set(handles.q_0_edit, 'String', quat(1));
    set(handles.q_1_edit, 'String', quat(2));
    set(handles.q_2_edit, 'String', quat(3));
    set(handles.q_3_edit, 'String', quat(4));
        
    