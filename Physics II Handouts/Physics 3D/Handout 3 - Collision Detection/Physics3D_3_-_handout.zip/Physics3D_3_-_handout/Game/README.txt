Press F1 to toggle debug mode

While in debug mode:
- 1 to shoot a sphere
- 2 to shoot a box
- 3 to shoot a cylinder
- 4 to center all primitives
- 5 to POW all primitives