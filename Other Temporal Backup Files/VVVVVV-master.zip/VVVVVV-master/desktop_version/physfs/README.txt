
PhysicsFS; a portable, flexible file i/o abstraction.

  https://icculus.org/physfs/

Please see the docs directory for documentation.

Please see LICENSE.txt for licensing information.

