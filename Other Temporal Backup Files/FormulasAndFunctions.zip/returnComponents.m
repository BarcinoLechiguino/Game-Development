function [Matrix, yaw, pitch, roll, u, theta, quat, vec] = returnComponents(inputType, i1, i2, i3)

% Given {a rotation matrix or Euler rotation angles
% or principal Euler axis/angle or quaternion or rotation vector},
% returns {a rotation matrix and Euler rotation angles
% and principal Euler axis/angle and quaternion and rotation vector}

% Use a letter 'm,r,e,q,v' to inform the function which are the input arguments in inputType. 
% Input 2 (i2) is only used with 'e' (Euler axis/angle) and 'r' (Euler rotation angles, which also use i3)

if inputType == 'm'
   Matrix = i1;
   [yaw, pitch, roll] = matrix2eulerangles(Matrix);        
   [theta, u] = matrix2euleruphi(Matrix);
   vec = euleruphi2rotationvector(u, theta);   
   quat = euleruphi2quaternion(u, theta);   
        
elseif inputType == 'r'
   pitch = i1;
   roll = i2;
   yaw = i3;
   Matrix = eulerangles2matrix(yaw, pitch, roll);      
   [theta, u] = matrix2euleruphi(Matrix);
   vec = euleruphi2rotationvector(u, theta);   
   quat = euleruphi2quaternion(u, theta);   
        
elseif inputType == 'q'
   quat = i1;
   [theta, u] = quaternion2euleruphi(quat);
   vec = euleruphi2rotationvector(u, theta);    
   Matrix = euleruphi2mat(u, theta);    
   [yaw, pitch, roll] = matrix2eulerangles(Matrix);
        
elseif inputType == 'v'
   vec = i1;
   [theta, u] = rotationvector2euleruphi(vec); 
   Matrix = euleruphi2mat(u, theta);    
   quat = euleruphi2quaternion(u, theta);    
   [yaw, pitch, roll] = matrix2eulerangles(Matrix);        

elseif inputType == 'e'
   u = i1;
   theta = i2;        
   quat = euleruphi2quaternion(u, theta);    
   vec = euleruphi2rotationvector(u, theta);    
   Matrix = euleruphi2mat(u, theta);    
   [yaw, pitch, roll] = matrix2eulerangles(Matrix);
    
end

end