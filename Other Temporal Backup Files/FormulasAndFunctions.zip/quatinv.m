function [p] = quatinv(q)
%
%
% This function calculates the inverse of a quaternion.
%
% INPUTS:
% q -> Quaternion
%
% OUTPUTS:
% p -> Inverse quaternion.
%
% R = [q(1), -q(2:4, 1), q(2:4, 1), q(1) * eye(3) + uxmatrix(q)] * p
% The 1 in (2:4, 1) represents that its the first column.

% Reshaping q to 4 rows and 1 column
q = reshape(q, [4 1]);

q = q / norm(q);


conjq = [q(1); -q(2); -q(3); -q(4)];
normq = norm(q)^2;

p = (1 / normq) * conjq;