function [yaw, pitch, roll] = matrix2eulerangles(R)
%
%
% Rotation matrix to Euler Angles (phi, theta, psi) / (roll, pitch, yaw)
%
% INPUTS:
% R -> Rotation Matrix calculated from the Euler Angles (yaw, pitch, roll -> 3 2 1).
%
% OUTPUTS:
% yaw   -> Angle of the Z axis (psi)
% pitch -> Angle of the Y axis (theta)
% roll  -> Angle of the X axis (roll)
%

pitch = -asind(R(3, 1));
 
 if(cos(pitch) == 0 && R(3, 1))
     roll = 0;
     yaw = atan2d(-R(2, 3), -R(1, 3));
     
 elseif(cos(pitch) == 0 && R(3, 1) == -1)
     roll = 0;
     yaw = atan2d(R(2, 3), R(1, 3));
     
 else
     roll = atan2d(R(3, 2)/cosd(pitch), R(3, 3)/cosd(pitch));
     yaw = atan2d(R(2, 1)/cosd(pitch), R(1, 1)/cosd(pitch));
 end
 
%  pitch = pitch * 180/pi;
%  roll = roll * 180/pi;
%  yaw = yaw * 180/pi;

% pitch   = -acos(R(3, 1));
% roll    = atand((R(2, 1) / cosd(pitch)) / (R(1, 1) / cosd(pitch)));
% yaw     = atand((R(2, 1) / cosd(pitch)) / (R(1, 1) / cosd(pitch)));

    