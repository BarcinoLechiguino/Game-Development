function [u, phi] = quaternion2euleruphi(q) 
%
% Quaternion to Principal Euler angle/axis.
% Returns an axis and an angle given a quaternion.
%
% INPUTS:
% q -> Quaternion.
%
% OUTPUTS:
% u   -> Angle of the rotation (Amount of rotation). The angle is returned in radians.
% phi -> Axis of the rotation.

%This is the rotation angle.
phi = acos((2 * q(1)^2) - 1);
aux = sin(phi / 2);

%This is the rotation axis vector.
u = [q(2)/aux; q(3)/aux; q(4)/aux];

disp('In Degrees')
phi = phi * 180/pi;