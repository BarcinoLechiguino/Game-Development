function [R] = rotateMatrixWithEuleruphi(u, phi)
%
%
% Rotate a matrix using Rodrigues' Formula
%
% INPUTS:
% u  -> Axis of the rotation
%phi -> Angle of the rotation (Amount of rotation).
%
% OUTPUTS:
% R -> The rotated matrix encoded in the quaternion.
%

if nargin < 1
    u = [1 0 0];
end

if nargin < 2
    phi = pi / 2;  
end

vec = reshape(u/norm(u), [3, 1]);
newAngle = (2 * pi * phi) / 360;
crossProduct = [0 -vec(3) vec(2); vec(3) 0 -vec(1); -vec(2) vec(1) 0];
    
R = (eye(3) * cos(newAngle)) + (1 - cos(newAngle)) * (vec * vec') + (crossProduct * sin(newAngle));