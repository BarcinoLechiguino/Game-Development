function [R] = eulerangles2matrix(yaw, pitch, roll)   
%
%
% Euler angles to matrix
%
% INPUTS:
% yaw   -> Angle of the Z axis (psi)
% pitch -> Angle of the Y axis (theta)
% roll  -> Angle of the X axis (phi)
%
% OUTPUTS:
% R -> The rotation matrix encoded in the Euler Angles(psi theta phi-> 3 2 1)
%
% R(psi, theta, phi) = [ cos(theta)*cos(psi), (cos(psi)*sin(theta)*sin(phi))-(cos(phi)*sin(psi)),   (cos(psi)*cos(phi)*sin(theta))+(sin(psi)*sin(phi));
%                        cos(theta)*sin(psi), (sin(psi)*sin(theta)*sin(phi)) + (cos(psi)*cos(phi)), (sin(psi)*sin(theta)*cos(phi))-(cos(psi)*sin(phi));
%                        -sin(theta),          cos(theta)*sin(phi),                                  cos(theta)*cos(phi)];
%

if (yaw > 6.28)
    yaw = yaw * 180/pi;
end

if (pitch > 6.28)
    pitch = pitch * 180/pi;
end

if (roll > 6.28)
    roll = roll * 180/pi;
end

R = [ cosd(pitch)*cosd(yaw), cosd(yaw)*sind(pitch)*sind(roll) - cosd(roll)*cosd(yaw), cosd(yaw)*cosd(yaw)*sind(pitch) + sind(yaw)*sind(roll);
      cosd(pitch)*sind(yaw), sind(yaw)*sind(pitch)*sind(roll) + cosd(roll)*cosd(yaw), sind(yaw)*sind(yaw)*sind(pitch) - cosd(yaw)*cosd(roll);
     -sind(pitch), cosd(pitch)*sind(roll), cosd(pitch)*cosd(roll)];

% Rroll   = [ 1,     0,         0;
%             0, cos(roll), sin(roll);
%             0, -sin(roll), cos(roll) ];
%      
% Rpitch  = [ cos(pitch), 0, sin(pitch);
%                 0,      1,     0;
%            -sin(pitch), 0, cos(pitch) ];
%       
% Ryaw    = [ cos(yaw), sin(yaw), 0;
%            -sin(yaw), cos(yaw), 0;
%             0,            0,    1 ];
%         
% R = Ryaw' * Rpitch' * Rroll';
     
     