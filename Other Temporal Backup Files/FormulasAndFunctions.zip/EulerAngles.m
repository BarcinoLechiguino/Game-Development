% Euler Principal Axis and Angle
% Rotation vector:
% u = Fixed axis; (Rotation of 90º in the Z axis --> u = Z)
% p = Original vector; (p = (1; 0; 0))
% phi = Rotation angle; (phi = pi / 2 rad = 90º)
% 
% vr = Rotation vector; (For p = (1; 0; 0) && phi = pi / 2, p' = (0; 1; 0)) | (vr will be represented on paper as p')
%
% vr = p * cos(phi) + (1 - cos(phi)) + (p' * u) * u + (u x p) * sin(phi);
% 
% (u x p) = ux * p = ux = [0 -u(3) u(2); u(3) 0 -u(1); -u(2) u(1) 0] * p;
% 
% vr = R(u, phi) * p;
% 
% 
% Rotation Matrix:
% R = Rotation matrix;
% phi = Rotation angle;
% u = Rotation Axis;
% 
% Rodrigues Formula:
% R = eye(3) * cos(phi) + (1 - cos(phi)) * (u' * u) + [u]x * sin(phi);
% 
% 
% Inverse Rotation:
% Symmetric matrix: A = A';
% Antisymmetric matrix: A' = -A;
% 
% Rodrigues Formula:
% R = eye(3) * cos(phi) + (1 - cos(phi)) * (u' * u) - [u]x * sin(phi);
% 
% Inverse of a rotation matrix:
% inv(A) = A';
% 
% From R to (u, phi)
% See matrix2euleruphi.m
% 
% Euler Angles (roll, pitch, yaw)
% Composition of simple rotations:
% See eulerangles2matrix.m
% See matrix2eulerangles.m
%
% From Euler Angles to Rotation matrix and viceversa:
% See eulerangles2matrix.m
% See matrix2eulerangles.m  
%

