function [u, phi] = matrix2euleruphi(R)
%
%
% Rotation matrix to Euler(u,phi). The angle will be returned in degrees.
%
% INPUTS:
% R -> Rotation Matrix.
%
% OUTPUTS:
% u  -> Angle of the rotation (Amount of rotation). The angle is returned in radians.
%phi -> Axis of the rotation.

phi = acosd((trace(R) - 1) / 2);
ux = ((R - R') / (2 * sind(phi)));
u = [ux(3, 2); ux(1, 3); ux(2, 1)];

%phi = phi * 180/pi;

if phi == 180
    aux_mat = (R - eye(3) * (-1)) / 2;
    u = [aux_mat(1,1); aux_mat(2,2); aux_mat(3,3)];
end

if isnan(u)
    if phi == 0
       u = [1; 1; 1] / sqrt(3);  % We return an axis (with module 1, of course) from the infinite that there are
    end
end