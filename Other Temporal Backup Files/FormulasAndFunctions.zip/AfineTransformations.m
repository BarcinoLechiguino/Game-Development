% Afine transformations:
%  
% --- Rotation in 2d:
% al = alpha;
% ala = -alpha;
% alb = alpha;
% 
% a = Origin A.
% b = Origin B.
% 
% xa = Rab * xb;
% xa = [cos(ala), sin(ala); -sin(ala), cos(ala)] * [xb(1); xb(2)]; 
% 
% xb = Rba * xa;
% xb = [cos(alb), sin(alb); -sin(alb), cos(alb)] * [xa(1); xa(2)]; 
% 
% Rab' = Rba;
% 
% --- Rotation plus displacement:
% pa = The position of point p seen from frame A.
% pb = The position of point p seen from frame B.
% Rab | Rba = The rotation matrix that relates the orientation of both frames.
% tab | tba = The displacement between frames seen from A | B.
% 
% Rab = [cos(ala), sin(ala); -sin(ala), cos(ala)];
% Rba = [cos(alb), sin(alb); -sin(alb), cos(alb)];
% 
% pa = Rab * pb + tab;
% pb = Rba * pa + tba;
% 
% --- Relating rotations and translations: 
% pa = Rab * pb + tab;
% pb = Rba * pa + tba;
% 
% Rab = inv(Rba) = Rba';
% Rba = inv(Rab) = Rab';
% 
% tab = -Rab * tba;
% tba = -Rba * tab;
% 
% --- Homogeneous coordinates:
% 0v = [0, 0, 0];
% 
% pa = [pa; 1]
% pb = [pb; 1]
% 
% [pa; 1] = [ Rab, tab; 0v, 1] * [pb; 1]
% [pb; 1] = [ Rba, tba; 0v, 1] * [pa; 1]
% 
% --- Translate a vector:
% t = tab = tba; (?)
% 
% v = [eye(3), t; 0v, 1] = [x + t; 1];
% 
% --- Rotate a vector:
% R = Rab = Rba; (?)
% v = [R, 0v'; 0v, 1] = [Rv; 1];
% 