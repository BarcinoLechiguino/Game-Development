function [R] = quaternion2matrix(q)
%
% Quaternion to Rotation Matrix.
%
% INPUTS:
% q -> Quaternion
%
% OUTPUTS:
% R -> Rotation Matrix

q = q / norm(q);

R = [q(1)^2 + q(2)^2 - q(3)^2 - q(4)^2, 2*q(2)*q(3) - 2*q(1)*q(4), 2*q(2)*q(4) + 2*q(1)*q(3);
     2*q(2)*q(3) + 2*q(1)*q(4), q(1)^2 - q(2)^2 + q(3)^2 - q(4)^2, 2*q(3)*q(4) - 2*q(1)*q(2);
     2*q(2)*q(4) - 2*q(1)*q(3), 2*q(3)*q(4) + 2*q(1)*q(2), q(1)^2 - q(2)^2 - q(3)^2 + q(4)^2];
 

% qv = [q(2); q(3); q(4)];
% 
% qx = [ 0, -q(4), q(3);
%        q(4), 0, -q(2);
%       -q(3), q(2), 0 ];
% 
% Rq = [ (q(1)^2 - qv' * qv) * eye(3) + 2 * qv * qv' + 2 * q(1) * qx ];