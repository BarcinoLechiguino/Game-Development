
% From Lab 2 we have two functions:
%
% *  Given principal Euler axis/angle, returns the rotation matrix.
% *  Given a set of Euler angles, returns the rotation matrix.
%
% We used the past functions and the function Cubeplot/Cubeplot2 to transform the
% orientation of the cube given by M
%

M = [    -1  -1 1;      %Node 1
    -1   1 1;           %Node 2
    1   1 1;            %Node 3
    1  -1 1;            %Node 4
    -1  -1 -1;          %Node 5
    -1   1 -1;          %Node 6
    1   1 -1;           %Node 7
    1  -1 -1]';         %Node 8

%
% Now it is time to complete all the transformations, 
% adding also the quaternions representation
%
% If not completed in Lab 2:
%
%% Exercise 0
% Create a function that implements the quaternion multiplication.
% Create a function that given a vector and a quaternion, returns the vector
% rotated by the attitude encoded in the quaternion using quaternion
% multiplications.
% Test it an argument/demonstrate why your function is well implemented.
q = [sqrt(2)/2; 0; 0; sqrt(2)/2];
p = [0; 2; 0; 0];

% It should have the result of [0; sqrt(2)/2; sqrt(2)/2; 0]
quatproduct(q, p)%;

i = [1; 0; 0; 0;];
var1 = quatproduct(q, i);

if q == var1
    disp("They are the same because the product of a matrix by the identity is the same matrix.");
end

% Rotation
% To check rotation we use an exercise we did in class
vec = [2 0 0];

% It should be the same as the result of [0; 0; 2; 0]
rotationquat(q, vec)

%
%% Exercise 1
% Create functions that:
%
% *  Given a rotation matrix, returns the Euler rotation angles.
% *  Given a rotation matrix, returns the principal Euler axis/angle.
% *  Given principal Euler axis/angle, returns the quaternion.
% *  Given a quaternion, returns the principal Euler axis/angle.
% *  Given principal Euler axis/angle, returns the rotation vector.
% *  Given the rotation vector, returns principal Euler axis/angle.
%
% Check the past functions and the function Cubeplot/Cubeplot2 to transform the
% orientation of the cube given by M
%These variables will be used to test the functions (Will be reset for each function):
R = [1 0 0; 0 cos(30) -sin(30); 0 sin(30) cos(30)];
yaw = 0; 
pitch = 0;
roll = 0;
u = [2 0 0]';
phi = pi;
q = [sqrt(2)/2; 0; 0; sqrt(2)/2];
r = [1 0 0]';

% Declared here are all the functions required in the exercise. To check
% them out see the .m files with the same name as the functions.
disp('This is the Euler Angles from the Rotation Matrix:');
R = [1 0 0; 0 cos(30) -sin(30); 0 sin(30) cos(30)];
[yaw, pitch, roll] = matrix2eulerangles(R)
R = eulerangles2matrix(yaw, pitch, roll)
N = R*M;
Cubeplot(N');

disp('This is the Euler(u, phi) from the Rotation Matrix:');
R = [1 0 0; 0 cos(30) -sin(30); 0 sin(30) cos(30)];
[u, phi] = matrix2euleruphi(R)
R = euleruphi2mat(u, phi)
N = R*M;
Cubeplot(N');

disp('This is the quaternion from the Euler (u, phi):');
u = [1 0 0]';
phi = 90;
q = euleruphi2quaternion(u, phi)
%N(:, 1) = rotationquat(M(:, 1), q);
%N(:, 2) = rotationquat(M(:, 2), q);
%N(:, 3) = rotationquat(M(:, 3), q);
%N(:, 4) = rotationquat(M(:, 4), q);
%N(:, 5) = rotationquat(M(:, 5), q);
%N(:, 6) = rotationquat(M(:, 6), q);
%N(:, 7) = rotationquat(M(:, 7), q);
%N(:, 8) = rotationquat(M(:, 8), q);
%Cubeplot(N');

disp('This is the Euler (u, phi) from the quaternion:');
q = [sqrt(2)/2; 0; 0; sqrt(2)/2];
[u, phi] = quaternion2euleruphi(q)
R = euleruphi2mat(u, phi)
N = R*M;
Cubeplot(N');

disp('This is the rotation vector from Euler (u, phi):');
u = [0 1 0]';
phi = 90;
r = euleruphi2rotationvector(u, phi)

disp('This is the (u, phi) of the rotation vector:');
u = [0 0 1]';
phi = 90;
[u, phi] = rotationvector2euleruphi(r)
R = euleruphi2mat(u, phi)
N = R*M;
Cubeplot(N');

%
%% Exercise 2
% Create a function that:
%
% *  Given {a rotation matrix or Euler rotation angles
%    or principal Euler axis/angle or quaternion or rotation vector},
%    returns {a rotation matrix and Euler rotation angles
%    and principal Euler axis/angle and quaternion and rotation vector}
%
% Hint: use a letter 'r,e,p,q,v' to inform the function which are the
%       input arguments. 
%

% This is the data that will be used to test the function:
R = [0.9254 0.0180  0.3785
     0.1632  0.8826  -0.4410
     -0.3420 0.4698  0.8138];

% Calling the function with the matrix
[R, yaw, pitch, roll, u, phi, q, r] = returnComponents('m', R);

% Calling the function with the received quaternion
[R, yaw, pitch, roll, u, phi, q, r] = returnComponents('q', q);

% Calling the function with the received Euler Principal Axis/Angle
[R, yaw, pitch, roll, u, phi, q, r] = returnComponents('e', u, phi);
