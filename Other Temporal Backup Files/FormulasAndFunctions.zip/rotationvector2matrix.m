function [R] = rotationvector2matrix(r)
%
%
% Rotation vector to Rotation Matrix. The vec has to have the following dimensions [3, 1]
%
% INPUTS:
% r -> Rotation Vector encoded in the Rotation Matrix.
%
% OUTPUTS:
% R -> Rotation Matrix.
%

phi = norm(r);
u = r / norm(r);

ux = [0 -u(3) u(2);
      u(3) 0 -u(1);
     -u(2) u(1) 0];
 
 R = eye(3) * cosd(phi) + (1 - cosd(phi)) * (u * u') + ux * sind(phi);