% Quaternions:
% q = [1, 1, 0, 0]';
% q0 = q(1) = 1;
% qv = q(2:4) = [1, 0, 0]';
% 
% 
% Quaternion multiplication:
% q = Quaternion 1;
% p = Quaternion 2;
% 
% Q(q) = [ q(1),           -qv';
%          qv, q(1) * eye(3) + [qv]x ];
% 
% ~Q(p) = [ q(1),          -qv';
%          qv, q(1) * eye(3) - [qv]x ];
% 
% Q = Mat 4x4;
% 
% q * p = Q(q) * p;
% q * p = ~Q(p) * q;
% 
% q * p = Q(q) * p = ~Q(p) * q;
% 
% 
% Quaternion Definitions:
% --- Conjugate:
% ~q = [q(1), -q(2), -q(3), -q(4)] = [q(1) ; -qv] | [1, 2, 3, 4] (Indexes)
% ~q = [q(0), -q(1), -q(2), -q(3)] = [q(0) ; -qv] | [0, 1, 2, 3] (Indexes)
% 
% q * ~q = [q(1); qv] * [q(1); -qv] = [norm(q)^2; 0]; | [1, 2, 3, 4] (Indexes)
% q * ~q = [q(0); qv] * [q(0); -qv] = [norm(q)^2; 0]; | [0, 1, 2, 3] (Indexes)
% 
% qv * (-qv) = 0;
% 
% --- Norm:
% norm(q)^2 = q * ~q = ~q * q = q(1)^2 + (qv' * qv) = q' * q = q(1)^2 * q(2)^2 * q(3)^2 * q(4)^2; | [1, 2, 3, 4] (Indexes)
% norm(q)^2 = q * ~q = ~q * q = q(1)^2 + (qv' * qv) = q' * q = q(0)^2 * q(1)^2 * q(2)^2 * q(3)^2; | [0, 1, 2, 3] (Indexes)
% 
% norm(q * p) = norm(q) * norm(p);
% norm(alpha * q) = norm(alpha) * norm(q); (?)
% 
% --- Pure Quaternion:
% q0 = q(0) = q(1) = 0;
% v = [0; vv];
% 
% --- Identity Quaternion:
% 0v = [0, 0, 0];
% qId = [1; 0v];
% qId * q = q * qId = q;
% 
% --- Inverse Quaternion:
% invq = (1 / norm(q)^2) * ~q;
% 
% --- Unit Quaternion:
% uq = q / norm(q);
% 
% 
% Rotations Using Quaternions:
% q = Unit quaternion;              (norm(q) = 1)
% v = Pure quaternion;              ([0; vv];)
% ~q = Unit quaternion conjugate;   ([q(1); -qv])
% 
% w = [0; wv]; = q * v * ~q;        (v * ~q is calculated first and then q * (v * ~q))
% wv = R(q) * vv;                   (wv has the same length as vv but rotated according to the rotation matrix encoded in q)
% 
% --- Rotating vv into wv using uq:
% vv = Rotation vector;
% 0v = [0; 0; 0];
% [0; wv] = [ 1, -0v'; 0v, R(q)]
% 
% Step 1: vv --> v = [0; vv];
% 
% Step 2: w = q * v * ~q = Q(q) * ~Q(~q) * v = [1, 0v'; 0v, R(q)]; 
% 
% Q(q)   = [ q(1),            -qv';
%            qv, q(1) * eye(3) + [qv]x ];
% 
% ~Q(~q) = [ q(1),            -qv';
%            qv, q(1) * eye(3) - [-qv]x ];
% 
% Conclusion:
% wv = R(q) * v;
% R(q) = [ (q(1)^2 - qv' * qv) * eye(3) + 2 * qv * qv' + 2 * q(1) * qx ];
% 
% 
% 
% 
% 