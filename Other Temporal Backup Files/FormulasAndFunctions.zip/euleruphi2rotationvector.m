function [r] = euleruphi2rotationvector(u, phi)    
%
% Euler axis/angle to rotation vector.
% Returns a rotation vector given axis and an angle.
%
% INPUTS:
% u   -> Axis of the rotation.
% phi -> Angle of the rotation (Amount of rotation). The angle is returned in radians.
%
% OUTPUTS:
% r  -> Rotation vector.

r = phi * u;
