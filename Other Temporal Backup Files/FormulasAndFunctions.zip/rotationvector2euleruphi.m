function [u, phi] = rotationvector2euleruphi(r)
%
% Quaternion to Principal Euler angle/axis.
% Returns an axis and an angle given a quaternion.
%
% INPUTS:
% r  -> Rotation vector.
%
% OUTPUTS:
% u   -> Angle of the rotation (Amount of rotation). The angle is returned in radians.
% phi -> Axis of the rotation.

u = r/norm(r);
phi = norm(r);

disp('In Degrees')
phi = phi * 180/pi;