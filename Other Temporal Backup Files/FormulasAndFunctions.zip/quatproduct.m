function [R] = quatproduct(q, p)
%
%
% This function calculates the product of two quaternions.
%
% INPUTS:
% q -> First quaternion
% p -> Second quaternion.
%
% OUTPUTS:
% R -> Quaternion resulting from the product of p and q in that order.
%
% R = [q(1), -q(2:4, 1), q(2:4, 1), q(1) * eye(3) + uxmatrix(q)] * p
% The 1 in (2:4, 1) represents that its the first column.

% Reshaping q to 4 rows and 1 column
q = reshape(q, [4 1]);

% Reshaping p to 4 rows and 1 column
p = reshape(p, [4 1]);

% Checking the norm of q so it is known if it is a rotation or not. q = 1 represents a rotation.
q = q/norm(q);

R = [q(1), -q(2:4, 1)'; q(2:4, 1), (q(1) * eye(3)) + uxmatrix(q)] * p;
