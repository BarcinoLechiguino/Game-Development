function [Ux] = quaternion2uxmatrix(q)
%
%
% This function calculates the matrix of a vector.
%
% INPUTS:
% q -> Vector(4, 1).
%
% OUTPUTS:
% Ux -> Matrix.
%
% For vectors(3, 1): Ex: u -> vector
% ux = [0 -u(3) u(2); u(3) 0 -u(1); -u(2) u(1) 0];
%
% For vectors coming from quaternions: q -> vector (4, 1)

 Ux = [0 -q(4) q(3); q(4) 0 -q(2); -q(3) q(2) 0];