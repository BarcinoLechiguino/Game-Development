% TRANSFORMATIONS
%
% T --> Transformation
% 
% 1.- T(O) = O --> O = [0, 0, 0];
% 2.- T(lambda * u + mu * v) = lambda * T(u) + mu * T(v);
% 
%  --- Example
% T(x1, x2, x3) = [ x1 + 2 * x2;
%                    3 * x3;
%                  -x1 + x3 ];
%              
% 1.- T(O) = [ 0 + 2 * 0;  --> T(O) = [0; 0; 0] = [0, 0, 0]; 
%              3 * 0;
%             -0 + 0 ];
%         
% 2.- T(lambda * u + mu * v) = T([lambda * u1; lambda * u2; lambda * u3] + [mu * v1; mu * v2; mu * v3]) -->
%                            
%                            = lambda * T(u) + mu * T(v) = lambda * [ u1 + 2 * u2;  +  mu * [ v1 + 2 * v2; -->
%                                                                      3 * u3;                 3 * v3;
%                                                                    -u1 + u3 ];             -v1 + v3 ];
% 
%                            = lambda * (u1 + 2 * u2) + mu (v1 + 2 * v2);
%                            = lambda * (3 * u3) + mu (3 * v3);
%                            = lambda * (-u1 + u3) + mu (-v1 + v3);
%
%
% T(x) = T * x;
% 
% 
% ROTATIONS 
% 
% Vector Norm --> v = sqrt(v(1)^2 + v(2)^2 + ... + v(n)^2) = sqrt(v' * v);
% 
% Dot Product --> u * v = u' * v = u(1) * v(1) + u(2) * v(2) + ... + u(n) * v(n) = norm(u) * norm(v) * cos(alpha); 
% Angle between vectors --> cos(alpha) = (u * v) / (norm(u) * norm(v));
%                           Angle = acos(cos(alpha));
% 
% Triple Product --> u'(v x w);
% 
% Orthongonal Base --> u * v = 0;   If u * v = 0, then u and v are perpendicular to each other.
% Ortonormal Base --> norm(w) = 1;  w = u x v (?)
% 
% A matrix R is a rotation matrix when:
% 
% det(R) = 1;
% inv(R) = R';
% 
% Example: Rotation of 90º in the Z axis
% 
% Z will remain still as it is the rotation axis.
% 
% Rule of the right hand: [x, y, z] --> [y, -x, z];
% 




                                                                    
                           
