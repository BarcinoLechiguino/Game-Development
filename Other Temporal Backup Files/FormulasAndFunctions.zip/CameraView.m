% Camera View:
% 
% Thales Theorem:
% X = Vertical vector past the camera. (Depends on the rotation of the origin)
% Y = Vertical vector past the camera. (Depends on the rotation of the origin)
% Z = Horizontal vector from origin to observed point.
% x = Vertical vector at camera pos. (Depends on the rotation of the origin)
% y = Vertical vector at camera pos. (Depends on the rotation of the origin)
% f = Horizontal vector from origin to camera.
% 
% X / Z = x / f;
% Y / Z ) y / f;
% 
% --- Camera Point:
% p = [x; y] = [(X / Z) * f; (Y / Z) * f];
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 