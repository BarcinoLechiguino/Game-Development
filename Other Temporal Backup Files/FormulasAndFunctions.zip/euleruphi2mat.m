function [R] = euleruphi2mat(u, phi)
% Rodrigues Formula
% R = Identity * cos(phi) + (1 - cos(phi)) * u * ut + [u]x * sin(phi)

%Check if the angle passed as argument is in degrees or radians
if (phi > 6.28)
    phi = (phi * pi) / 180;
end

%Careful with this.
reshape(u, 3, 1);   %Returning the vector as 3 rows and 1 column. 
size(u, 1);         %Checks the size of the vector's rows.       
size(u, 2);         %Checks the size of the vector's columns.

%If det = 1, then the matrix is a rotation matrix
% Checking norm = 1
u = u / norm(u);    %Dividing it by the norm
 
% Calculate [u]_x
ux = [0 -u(3) u(2);
      u(3) 0 -u(1);
     -u(2) u(1) 0];

%Apply Rodrigues fomula / we suppose the users are smart enough to pass radians as function argument
R = eye(3) * cosd(phi) + (1 - cosd(phi)) * (u * u') + ux * sind(phi);
V = R * u;