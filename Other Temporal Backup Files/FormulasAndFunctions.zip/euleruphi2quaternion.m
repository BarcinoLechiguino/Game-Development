function [q] = euleruphi2quaternion(u, phi)
%
% Principal Euler angle/axis to Quaternion.
% Returns a quaternion given an axis and an angle.
%
% INPUTS:
% u  -> Axis of the rotation. 
%phi -> Angle of the rotation (Amount of rotation). The angle is returned in radians.
%
% OUTPUTS:
% q -> Quaternion.

%Gets the vector and the auxuliar.
v = u / norm(u);
aux = sin(phi / 2);

% Calculates the quaternion.
q = [cos(phi / 2); v(1) * aux; v(2) * aux; v(3) * aux];


% q = [ cos(phi / 2);
%       v * sin(phi / 2) ];