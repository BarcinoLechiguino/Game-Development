function [w] = rotationquat(q,v)
%
%
% This function calculates the rotation of a vector encoded in a quaternion.
%
% INPUTS:
% q -> Quaternion
% v -> Vector to be rotated.
%
% OUTPUTS:
% w -> Rotated vector.
%
% quat(w) = quat(q) * quat(v) * quat(conj(q));
%
% w = quat(w)(2:4) To get the rotated vector, the quaternion's real part (q0) is eliminated.
%

% Resetting everything into sth that can be worked with.
v = reshape(v, [3 1]); 
q = reshape(q, [4 1]);
q = q/norm(q);

% Calculate quat(v)
quat_v = [0;v];

% Calculate quat(conj(q))
quatconj_q = [q(1, 1); -q(2:4, 1)];   %q(1, 1) is the first element of the quaternion, the real part. Elements 2 to 4 are the imaginary part, a vector.

% Calculate quat(v) * quat(conj(q))
quat_auxiliar = quatproduct(quat_v, quatconj_q);  %See quatproduct function.

% Calculate quatw = quat(q) * quat(v) * quat(conj(q))
quat_w = quatproduct(q, quat_auxiliar);    %Calculates the w quaternion as the result of q * quatv.

% Get w
w = quat_w(2:4, 1);  %Get the vector (imaginary part) of the quaternion.
